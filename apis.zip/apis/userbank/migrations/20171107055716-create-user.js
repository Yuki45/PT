'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('users', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      username: {
        type: Sequelize.STRING(16)
      },
      name: {
        type: Sequelize.STRING(40)
      },
      password: {
        type: Sequelize.CHAR(64)
      },
      login_token: {
        type: Sequelize.CHAR(64)
      },
      remember_token: {
        type: Sequelize.CHAR(64)
      },
      reset_token: {
        type: Sequelize.CHAR(64)
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('users');
  }
};
