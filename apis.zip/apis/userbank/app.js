// app.js
// --irfan

require('dotenv').config();  // Load env configuration

var path = require('path');  // Load path module
var os = require('os');  // Load os module
var fs = require('fs');  // Load filesystem module

global.appRoot = path.resolve(__dirname);  // Set appRoot to current root project directory

var Router = require('restify-router').Router;  // better router for restify
var restify = require('restify');  // restify core


var db = require( appRoot + '/lib/db');  // Load db SQL builder
var routes = require('./lib/routes/routes');  // Load routes


require('./models');  // Load sequelize models
require( appRoot + '/lib/creators' );  // Load library creators
require( appRoot + '/lib/auths' );  // Load library auths

restify.plugins = require('restify-plugins');  // Inject restify plugins

var routerInstance = new Router();  // Create new routerInstance

// Create restify server
var server = restify.createServer({
    name: 'apis_userbank',
    version: '0.1.0',
    // key: fs.readFileSync('./ssl/server.key'),
    // certificate: fs.readFileSync('./ssl/server.cert')
});

server.use( restify.plugins.queryParser () );
server.use( restify.plugins.bodyParser({
    maxBodySize: 0,
    mapParams: true,
    mapFiles: false,
    overrideParams: false,
    multipartHandler: function(part) {
        part.on('data', function(data) {
          // do something with the multipart data
        });
    },
   multipartFileHandler: function(part) {
        part.on('data', function(data) {
          // do something with the multipart file data
        });
    },
    keepExtensions: false,
    uploadDir: os.tmpdir(),
    multiples: true,
    hash: 'sha2',
    rejectUnknown: true,
    requestBodyOnGet: false,
    reviver: undefined,
    maxFieldsSize: 2 * 1024 * 1024
 }));

routes.applyRoutes( server, '/' );  // Load server

server.listen( process.env.SERVER_PORT, function() {  // Start listening port
  console.log('%s @%s listening at port %s', server.name, server.versions, process.env.SERVER_PORT);
});
