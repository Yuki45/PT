'use strict';

module.exports = (sequelize, DataTypes) => {
  var Group = sequelize.define('Group', {
    name: DataTypes.STRING(16),
    display_name: DataTypes.STRING(25),
    description: DataTypes.STRING(40),
    api_key: DataTypes.CHAR(64)
  }, {
    tableName: 'groups',
    underscored: true
  });

  // Associate group
  Group.associate = function( models ) {

    Group.hasMany( models.Role, {
      foreignKey: 'group_id',
      sourceKey: 'id'
    });
  }
  return Group;
};
