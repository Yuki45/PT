'use strict';

module.exports = (sequelize, DataTypes) => {
  var User = sequelize.define('User', {
    username: DataTypes.STRING(16),
    name: DataTypes.STRING(40),
    password: DataTypes.CHAR(64),
    login_token: DataTypes.CHAR(64),
    remember_token: DataTypes.CHAR(64),
    reset_token: DataTypes.CHAR(64)
  }, {
    tableName: 'users',
    underscored: true
  });

  User.associate = function( models ) {

    // One to Many role_user relationship
    models.User.belongsToMany( models.Role, {
      through: 'role_user',
      timestamps: false
    });
  };

  // Check if user is exists
  User.prototype.isExists = function( conditions ){
    return User.count({ where: conditions })
      .then(count => {
        if (count != 0) {
          return false;
        }
        return true;
    });
  };

  return User;
};
