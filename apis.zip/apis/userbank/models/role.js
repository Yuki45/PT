'use strict';

module.exports = (sequelize, DataTypes) => {
  var Role = sequelize.define('Role', {
    name: DataTypes.STRING,
    display_name: DataTypes.STRING,
    description: DataTypes.STRING,
    group_id: DataTypes.INTEGER
  }, {
    tableName: 'roles',
    underscored: true
  });

  Role.associate = function( models ) {

    Role.belongsTo( models.Group, {
      foreignKey: 'group_id',
      sourceKey: 'id'
    });

    Role.belongsToMany( models.User, {
      through: 'role_user',
      timestamps: false
    });

    Role.belongsToMany( models.Permission, {
      through: 'role_permission',
      timestamps: false
    });
  }

  return Role;
};
