'use strict';
module.exports = (sequelize, DataTypes) => {
  var Permission = sequelize.define('Permission', {
    name: DataTypes.STRING,
    display_name: DataTypes.STRING,
    description: DataTypes.STRING
  }, {
    tableName: 'permissions',
    underscored: true
  });

  Permission.associate = function( models ) {

    Permission.belongsToMany( models.Role, {
      through: 'role_permission',
      timestamps: false
    });

  }

  return Permission;
};
