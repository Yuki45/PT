require('dotenv').config();  // Load .env configuration to process.env

const os = require('os');  // Load os package

var restify = require('restify');  // Load restify package
restify.plugins = require('restify-plugins');  // Load restify plugins

const api_key = {
    'dwi.nopita@samsung.com': '4302C0E8782E0A45567CD53CCA69A216EDADFC141EEE749EAA025C4BEFE8931A'
};

const mailer = require('./lib/mailer')(api_key);  // Load Mailer Library
const logger = require('./lib/logger');  // Load logger library

// Create restify server    
var server = restify.createServer({
    name: 'apis_smtp',
    version: '0.1.0',
    // log: logger.restifyLogger()
});

server.use(restify.plugins.queryParser());
server.use(restify.plugins.bodyParser({
    maxBodySize: 0,
    mapParams: true,
    mapFiles: false,
    overrideParams: false,
    multipartHandler: function(part) {
        part.on('data', function(data) {
          // do something with the multipart data
        });
    },
   multipartFileHandler: function(part) {
        part.on('data', function(data) {
          // do something with the multipart file data
        });
    },
    keepExtensions: false,
    uploadDir: os.tmpdir(),
    multiples: true,
    hash: 'sha1',
    rejectUnknown: true,
    requestBodyOnGet: false,
    reviver: undefined,
    maxFieldsSize: 2 * 1024 * 1024
 }));

// Middleware logger
server.pre(function (request, response, next) {
  request.log.info({req: request}, 'start');        // (1)
  return next();
});

// '/send' http request
server.post( '/send', ( req, res, next ) => {

    let resObj = res;
    let nextObj = next;

    mailer.sendEmail( req.body.from, req.body.to, req.body.subject, req.body.content, req.body.api_key, ( err, info ) => {

        if ( err !== undefined ) {
            resObj.json( { status: 'error', msg: err } );
        } else {
            resObj.json( { status: 'success', msg: info } );
        }

    } );

});

// verify connection configuration
mailer.nodemailTransport.verify( (error, success) => {
   if (error) {
        console.log(error);
   } else {
        // Listen the server
        server.listen( process.env.SERVER_PORT, function() {
            console.log( '%s listening at %s', server.name, process.env.SERVER_PORT );
        });
   }
});
