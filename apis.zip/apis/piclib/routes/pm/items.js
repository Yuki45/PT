// PM Item routes
// --irfan

var Promise = require('bluebird');
var Router = require('restify-router').Router;  // Restify router modules
var moment = require('moment');  // Date Time Modules
var validate = require("validate.js");  // Data validator

var userbank = require( appRoot + '/lib/userbank' );
var db = require( appRoot + '/lib/db' );  // Load knex sql builder

const router = new Router();  // Create new router

// Check new PM Item
function checkNewPMItem( new_pm_item ) {

  return function () {

    return new Promise ( ( resolve, reject ) => {

      var rules = {

        pm_head_id: {
          presence: {
            allowEmpty: false
          },
          numericality: {
            onlyInteger: true
          }
        },
        machine_id: {
          presence: {
            allowEmpty: false
          },
          numericality: {
            onlyInteger: true
          }
        },
        value: {
          length: {
            maximum: 8
          }
        },
        start_at: {
          presence: {
            allowEmpty: false
          },
          datetime: {
            dateOnly: false
          }
        },
        finish_at: {
          presence: {
            allowEmpty: false
          },
          datetime: {
            dateOnly: false
          }
        },
        created_by: {
          numericality: {
            onlyInteger: true
          }
        },
        updated_by: {
          numericality: {
            onlyInteger: true
          }
        }

      };

      var err = validate( new_pm_item, rules);

      if ( err ) {
        reject( err );
        return;
      }

      resolve( new_pm_item );

    });  // Promise
  }  // function

};

// Check mod PM Item
function checkModPMItem( mod_pm_item ) {

  return function () {

    return new Promise ( ( resolve, reject ) => {

      var rules = {

        pm_head_id: {
          numericality: {
            onlyInteger: true
          }
        },
        machine_id: {
          numericality: {
            onlyInteger: true
          }
        },
        value: {
          length: {
            maximum: 8
          }
        },start_at: {
          datetime: {
            dateOnly: false
          }
        },
        finish_at: {
          datetime: {
            dateOnly: false
          }
        },
        created_by: {
          numericality: {
            onlyInteger: true
          }
        },
        updated_by: {
          numericality: {
            onlyInteger: true
          }
        }

      };

      var err = validate( mod_pm_item, rules);

      if ( err ) {
        reject( err );
        return;
      }

      resolve( mod_pm_item );

    });  // Promise
  }  // function

};

// List all pms
router.get('/', ( req, res, next ) => {

  var cookies = req.cookies;

  var username = cookies.username;
  var login_token = cookies.login_token;

  var dateFilter = req.query.date_filter;

  if ( !username || !login_token ) {
    res.send({ success: false });
    return next();
  };

  userbank.token( username, login_token )
  .then( userbank.checkPermission_g( 'pm_items_list' ) )

  .then( function() {

    var pm_items = db( 'v_pms' )

    if ( typeof dateFilter === 'string' ) {

      dateFilter = dateFilter.split(' - ');

      dateFilter = dateFilter.map( function ( item ) {  // Subtract 7 hour for GMES date
        return moment( item )
        .add( 7, 'hours' )
        .format('YYYY-MM-DD HH:mm:ss');
      });

    } else {

      dateFilter = [

        moment().startOf( 'day' )
        .add( 7, 'hours' )
        .format('YYYY-MM-DD HH:mm:ss'),

        moment().startOf( 'day' )
        .add( 1, 'days')
        .add( 7, 'hours' )
        .format('YYYY-MM-DD HH:mm:ss')
      ];
    }

    pm_items = pm_items.where(function() {
      this.whereBetween( 'start_at', dateFilter )
      .orWhereBetween( 'start_at', dateFilter )
    });

    return pm_items.select( '*' );

  })
  .then( function( rows ) {

    res.send({ success: true, data: rows });
    return next();
  })
  .catch( function( err ) {

    res.send({ success: false, msg: err });
    return next();
  });

});

// Get current
router.get ( '/current', function ( req, res, next ) {

  var cookies = req.cookies;

  var username = cookies.username;
  var login_token = cookies.login_token;

  if ( !username || !login_token ) {
    res.send({ success: false });
    return next();
  };

  userbank.token( username, login_token )
  .then( userbank.checkPermission_g( 'pm_items_list' ) )

  .then( function() {

    return db( 'v_pm_current' )
    .select( '*' );

  })
  .then( function( rows ) {

    res.send({ success: true, data: rows });
    return next();
  })
  .catch( function( err ) {

    res.send({ success: false, msg: err });
    return next();
  });

});

// Get remain
router.get ( '/current/remain', function ( req, res, next ) {

  var cookies = req.cookies;

  var username = cookies.username;
  var login_token = cookies.login_token;

  var barcode = req.query.barcode;

  if ( !username || !login_token ) {
    res.send({ success: false });
    return next();
  };

  userbank.token( username, login_token )
  .then( userbank.checkPermission_g( 'pm_items_list' ) )

  .then( function() {

    return db( 'v_pm_current_remain' )
    .where('barcode', barcode)
    .select( '*' );

  })
  .then( function( rows ) {

    res.send({ success: true, data: rows });
    return next();
  })
  .catch( function( err ) {

    res.send({ success: false, msg: err });
    return next();
  });

});

// Submit new pm items
router.post( '/', ( req, res, next ) => {

  var cookies = req.cookies;

  var username = cookies.username;
  var login_token = cookies.login_token;
  var user;

  var barcode = req.body.barcode;
  var data = req.body.data;
  var start_at = req.body.start_at;
  var finish_at = req.body.finish_at;
  var location_id = req.body.location_id;
  var location_name = '';
  var line_changes = false;

  if ( !username || !login_token ) {
    res.send({ success: false });
    return next();
  };

  userbank.token( username, login_token )
  .then( u => {
    user = u;
    return u;
  })
  .then( userbank.checkPermission_g( 'pm_items_manage' ) )
  .then( function() {
    // Get Location name from db

    return db( 'locations' )
    .where( 'id', location_id )
    .select( 'name' )
    .limit( 1 );

  })
  .then( function( r ) {

    location_name = r[0].name;  // Assign location name

    // Get last location change histories
    return db( 'location_change_histories' )
    .where( 'machine_code', barcode )
    .select( 'location' )
    .orderBy( 'created_at', 'desc' )
    .limit( 1 );

  })
  .then( function ( r ) {

    // Check last location is changes
    if ( r ) {
      if ( r[0] ) {
        if ( r[0].location != location_name ) {
          line_changes = true;
        }
      } else {
        line_changes = true;
      }
    } else {
      line_changes = true;
    }
  })
  .then( function() {

    if ( line_changes  ) {

      return db( 'location_change_histories' )
      .insert({
        created_by: user.id,
        location: location_name,
        remark: 'PM',
        machine_code: barcode
      });
    }

  })
  .then( function() {

    return db( 'machines' )
    .where( 'barcode', barcode )
    .limit( 1 )
    .returning('id')
    .update( {
      'location_id': location_id,
      'updated_by': user.id,
      'updated_at': moment()
    });

  })
  .then( function ( machine_id ) {
    var datas = [];
    data.forEach( function ( item ) {
      datas.push({
        pm_head_id: item.id,
        machine_id: machine_id[0],
        status: item.status,
        value: item.value,
        remark: item.remark,
        start_at: item.start_at,
        finish_at: item.finish_at,
        created_by: user.id,
        location_id: location_id
      });
    });

    return db( 'pm_items' )
    .returning( 'id' )
    .insert( datas );
  })
  .then( function( pm_item ) {

    res.send({ success: true, pm_head: pm_item });
    return next();
  })
  .catch( function( err ) {

    res.send({ success: false, msg: err });
    return next();
  });

});

// Update PM item
router.patch( '/', ( req, res, next ) => {

  var cookies = req.cookies;

  var username = cookies.username;
  var login_token = cookies.login_token;
  var mod_pm_item = req.body;

  if ( !username || !login_token ) {
    res.send({ success: false });
    return next();
  };

  userbank.token( username, login_token )
  .then( function(user) {
    mod_pm_item.updated_by = user.id;
    mod_pm_item.updated_at = moment();

    return user;
  })
  .then( userbank.checkPermission_g( 'pm_items_manage' ) )
  .then( checkModPMItem( mod_pm_item ) )  // Check PM Item vars
  .then( function( data ) {
    var id = data.id;
    delete data.id;

    return db( 'pm_items' )
    .where( 'id', id )
    .returning( '*' )
    .update( data );
  })
  .then( function( result ) {

    res.send({ success: true, pm_item: result });
    return next();
  })
  .catch( function( err ) {

    res.send({ success: false, msg: err });
    return next();
  });

});

// Delete PM Item
router.del( '/', ( req, res, next ) => {

  var cookies = req.cookies;

  var username = cookies.username;
  var login_token = cookies.login_token;
  var pm_item_id = req.body.id;
  var pm_item = {};

  if ( !username || !login_token ) {
    res.send({ success: false });
    return next();
  };

  userbank.token( username, login_token )
  .then( function(user) {
    pm_item.updated_by = user.id;
    pm_item.updated_at = moment();
    pm_item.deleted_at = moment();

    return user;
  })
  .then( userbank.checkPermission_g( 'pm_items_manage' ) )
  .then( function() {

    return db( 'pm_items' )
    .where( 'id', pm_item_id )
    .returning( '*' )
    .update( pm_item );
  })
  .then( function( result ) {

    res.send({ success: true, pm_item: result });
    return next();
  })
  .catch( function( err ) {

    res.send({ success: false, msg: err });
    return next();
  });

});

module.exports = router;
